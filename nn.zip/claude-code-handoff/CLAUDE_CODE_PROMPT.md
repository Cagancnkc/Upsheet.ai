# Claude Code Görevi — Fiyatlandırma Bölümü Tasarım Güncellemesi

## 🎯 Görev özeti

Mevcut fiyatlandırma/abonelik sayfasının **görsel tasarımını** ektedeki referans dosyaya göre güncelle. **Backend, API, veritabanı, ödeme entegrasyonu veya iş mantığına ait HİÇBİR dosyaya dokunma.** Bu görev tamamen **sunum katmanı** ile sınırlı.

## 📎 Referans dosya

`Pricing Section A.html` — Yeni tasarımın eksiksiz uygulaması. HTML + CSS + minimal vanilla JS. Sayfaya gömülebilir tek bir `<section>` bloğu olarak yazılmıştır. Tüm stiller `.ms-pricing-a` kapsayıcısı altında prefix'lenmiştir, mevcut CSS'i kırmaz.

## ✅ Yapılacaklar

1. **Mevcut fiyatlandırma bölümünü tespit et** — Genellikle `Pricing`, `Plans`, `Subscription`, `Fiyatlandirma` gibi isimde bir component/sayfa olur.
2. **Sadece görünüm kodunu (markup + styles) değiştir:**
   - HTML/JSX yapısını referans dosyadakiyle eşleştir
   - CSS sınıflarını ve stillerini birebir uygula
   - "Aylık / Yıllık" toggle JS mantığını koru
3. **Mevcut props / state / fonksiyonları olduğu gibi koru** — örn. plan verileri, fiyat hesaplamaları, "Subscribe" handler'ları, Google OAuth fonksiyonu, Stripe/Iyzico çağrıları → **AYNEN KALACAK**, sadece görsel kabuk değişecek.
4. **Eğer projeniz React/Next.js/Vue ise:**
   - HTML → JSX'e çevir (`class` → `className`, `for` → `htmlFor`)
   - Inline `<script>` toggle'ını component state'ine taşı (`useState` / `ref`)
   - Stilleri CSS module / Tailwind / styled-components olarak uyarla, ama **görsel sonuç birebir aynı olmalı**
5. **Fontları yükle:** Geist, Geist Mono, Instrument Serif (Google Fonts). Mevcut font yükleme stratejinizle (next/font, link tag vb.) entegre et.

## 🛑 Yapılmayacaklar — KESİNLİKLE

- ❌ Backend dosyalarına dokunma (`/api`, `/server`, `/lib/db`, `/services`, controller'lar, route handler'lar)
- ❌ Veritabanı şeması, migration veya seed dosyalarını değiştirme
- ❌ Ödeme/abonelik entegrasyon kodunu (Stripe, Iyzico, vs.) değiştirme
- ❌ Auth/OAuth kodunu değiştirme — sadece "Google ile kayıt ol" butonunun **görsel hali** güncellenecek, fonksiyon imzası aynı kalacak
- ❌ Plan fiyatlarını veya isimlerini hard-code etmeye çalışma — eğer mevcut kodda dinamik olarak çekiliyorsa, dinamik veri akışını koru, sadece görsel template'i değiştir
- ❌ Routing, middleware, environment variable veya config dosyalarına dokunma
- ❌ Test dosyalarını silme — değişen UI selector'larına göre güncelle

## 📋 Kabul kriterleri

- [ ] Bölüm görsel olarak referans dosyaya birebir benziyor (beyaz arka plan, mor `#6d28d9` vurgular, siyah CTA'lar, italik serif başlık, yatay sıralar)
- [ ] "Aylık ↔ Yıllık" toggle çalışıyor, fiyat metinleri güncelleniyor
- [ ] "Google ile kayıt ol" butonu mevcut auth fonksiyonunu çağırıyor (kod değişmedi)
- [ ] Pro plan ortada vurgulanmış (soft purple background)
- [ ] Mobil görünüm referansa uygun (980px breakpoint)
- [ ] Backend, API, DB, auth, ödeme entegrasyon dosyalarına **hiç dokunulmamış** (`git diff` ile teyit edilebilir)
- [ ] Mevcut testler geçiyor; UI selector'ları değişti ise testler güncellenmiş

## ⚠️ Belirsizlik durumu

Eğer mevcut kod tabanında bu görevle ilgili bir konuda emin değilsen (örn. plan verilerinin nereden çekildiği, hangi component'i değiştireceğin, fontların nasıl yükleneceği) **dosyayı değiştirmeden önce sor**. Tahmin yürüterek backend dosyalarına dokunma.

## 🎨 Tasarım özeti (referans için)

- **Palet:** Beyaz arka plan, mor `#6d28d9` aksanlar, soft mor `#ede9fe` Pro plan washı, siyah `#0a0612` ink ve birincil CTA
- **Tipografi:** Geist (gövde), Instrument Serif italik (vurgu), Geist Mono (mikro etiketler)
- **Düzen:** 3 plan kart yerine **yatay sıralar** halinde — sol: "01/02/03" serif italik numara, orta: isim + özellikler, sağ: fiyat ve CTA
- **CTA stilleri:** Free (Google logolu ghost), Pro (siyah filled), Team (siyah outline)

---

Sorum varsa sor, yoksa başla. **Backend'e dokunma.**
